public class Main {

    public static void main(String[] args) {
        Employee myEmployee = new Employee("Ben Morris", 888, 'B', 1999, 9, 23);
        HourlyWorker myHourlyWorker = new HourlyWorker(1, 6.25);
        SalariedWorker mySalariedWorker = new SalariedWorker(70000,7000);
        TeamLeader myTeamLeader = new TeamLeader(450, 60, 45);

        System.out.print(myEmployee);
        System.out.print(myHourlyWorker);
        System.out.print(mySalariedWorker);
        System.out.println(myTeamLeader);
    }
}
